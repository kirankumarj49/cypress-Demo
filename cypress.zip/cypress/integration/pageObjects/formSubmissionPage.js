class formSubmissionPage
{
    getInputName()
    {
        return cy.get('input[type="text"]')
    }
    getRadioButton()
    {
        return cy.get("div[id='i12'] div[class='AB7Lab Id5V1']")
    }
    getDropDown()
    {
        return cy.get('div[role="listbox"]');
    }
    getsubmit()
    {
        return cy.get('.lRwqcd > .uArJ5e > .l4V7wb')
    }
getShopTab()
    {
        return cy.get(':nth-child(2) >.nav-link')
    }
}

export default formSubmissionPage;