
import formSubmissionPage from "../pageObjects/formSubmissionPage"
const formSubmission= new formSubmissionPage()
describe('Google Form Test', () => {
    it('Fills out and submits the form', () => {
      // 1. Navigate to the form
      cy.visit(Cypress.env('url'))
      
      // 2. Enter your name in the “Your Name” field
      formSubmission.getInputName().type('John Doe');

      // 3. Select the “18 and above” radio button
      formSubmission.getRadioButton().click();

      // 4. Select “Yes” from the “Do you exercise every week?” dropdown
    formSubmission.getDropDown().click().contains('div[role="option"]', 'Yes').click()

      // 5. Submit the form
      formSubmission.getsubmit().click()

      // 6. Verify that the form submission is successful
      // Check for a confirmation message
      cy.contains('Your response has been recorded');
    });
  });